# IT-FrontendWebDevelopment-BriarPatch

# About
Created a web application using Angular where users are tasked at finding a rabbit sprite within a briar patch, cube-styled board.

<img width="1052" alt="Screen Shot 2022-07-26 at 10 30 02 AM" src="https://user-images.githubusercontent.com/52668142/181123017-d653fe9f-d1c7-469e-b3a4-616f871e7b6d.png">


