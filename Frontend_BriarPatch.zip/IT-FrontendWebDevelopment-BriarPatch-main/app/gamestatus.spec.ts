import { Gamestatus } from './gamestatus';

describe('Gamestatus', () => {
  it('should create an instance', () => {
    expect(new Gamestatus()).toBeTruthy();
  });
});
