import { Gamelogic } from './gamelogic';

describe('Gamelogic', () => {
  it('should create an instance', () => {
    expect(new Gamelogic()).toBeTruthy();
  });
});
