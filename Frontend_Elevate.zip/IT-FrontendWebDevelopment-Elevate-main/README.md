# IT-FrontendWebDevelopment-Elevate

Created a sample Task Management list using CSS Bootstrap notation.

# Local Host Browser View

<img width="615" alt="Screen Shot 2022-07-23 at 8 37 20 PM" src="https://user-images.githubusercontent.com/52668142/181587255-47bee054-b587-4e68-ae88-ff1436f7da49.png">
